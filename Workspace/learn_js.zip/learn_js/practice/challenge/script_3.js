'use strict';

{
  //フォームを取得
  const form = document.forms.profile;

  //フォームのsubmitボタンを押した時にイベント発生させる
  
        //勝手にリロードしないように設定
  form.name

    //コンソールにフォームの値を表示させる
    
}

{
  const target = document.querySelector('.target');

  //クラス名を追加して文字の色を変えよう

  //クラス名を削除して文字の色を元に戻そう
}

{
  //多重ループで名前生成してみよう〜
  //それぞれ苗字と名前を全パターン組み合わせて表示させる
  const firstName = ['咲希', '亮', '颯人', '達弘'];
  const lastName = ['飯田', '猪瀬', '生川', '関根', '藤井', '江口'];

}